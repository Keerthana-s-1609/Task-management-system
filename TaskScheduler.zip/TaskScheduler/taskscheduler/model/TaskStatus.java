package taskscheduler.model;

public enum TaskStatus {
    PENDING,
    COMPLETED,
    IN_PROGRESS
}