package taskscheduler.service;

import taskscheduler.model.*;
import java.io.Serializable;
import java.util.*;

public class SchedulingEngine implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final double BUFFER_TIME = 0.25;
    
    private Map<String, List<ScheduledTask>> schedule;
    private List<Task> unscheduledTasks;
    private static final String[] DAYS = {"Monday", "Tuesday", "Wednesday", 
                                         "Thursday", "Friday", "Saturday", "Sunday"};
    
    public SchedulingEngine() {
        this.schedule = new LinkedHashMap<>();
        this.unscheduledTasks = new ArrayList<>();
        initializeSchedule();
    }
    
    private void initializeSchedule() {
        for (String day : DAYS) {
            schedule.put(day, new ArrayList<>());
        }
    }
    
    public boolean generateSchedule(List<Task> tasks, 
                                   List<TimeSlot> weekdaySlots, 
                                   List<TimeSlot> weekendSlots) {
        initializeSchedule();
        unscheduledTasks.clear();
        
        Queue<Task> taskQueue = new PriorityQueue<>(tasks);
        
        int dayIndex = 0;
        int slotIndex = 0;
        double currentSlotTimeUsed = 0;
        
        while (!taskQueue.isEmpty()) {
            Task task = taskQueue.poll();
            double taskDuration = task.getDurationHours();
            boolean scheduled = false;
            int attempts = 0;
            int splitPart = 1;
            double remainingTaskDuration = taskDuration;
            
            while (remainingTaskDuration > 0 && attempts < 14) {
                String currentDay = DAYS[dayIndex % 7];
                List<TimeSlot> availableSlots = isWeekend(currentDay) ? 
                                                weekendSlots : weekdaySlots;
                
                if (availableSlots.isEmpty()) {
                    dayIndex++;
                    attempts++;
                    slotIndex = 0;
                    currentSlotTimeUsed = 0;
                    continue;
                }
                
                if (slotIndex >= availableSlots.size()) {
                    dayIndex++;
                    attempts++;
                    slotIndex = 0;
                    currentSlotTimeUsed = 0;
                    continue;
                }
                
                TimeSlot currentSlot = availableSlots.get(slotIndex);
                double remainingSlotTime = currentSlot.getDurationHours() - currentSlotTimeUsed;
                
                if (remainingSlotTime >= BUFFER_TIME) {
                    double timeToSchedule = Math.min(remainingTaskDuration, remainingSlotTime - BUFFER_TIME);
                    
                    String startTime = calculateTime(currentSlot.getStartHour(), 
                                                    currentSlot.getStartMinute(), 
                                                    currentSlotTimeUsed);
                    String endTime = calculateTime(currentSlot.getStartHour(), 
                                                  currentSlot.getStartMinute(), 
                                                  currentSlotTimeUsed + timeToSchedule);
                    
                    ScheduledTask st;
                    if (remainingTaskDuration > remainingSlotTime - BUFFER_TIME) {
                        st = new ScheduledTask(task, currentDay, startTime, endTime);
                        splitPart++;
                    } else {
                        st = new ScheduledTask(task, currentDay, startTime, endTime);
                    }
                    
                    schedule.get(currentDay).add(st);
                    
                    remainingTaskDuration -= timeToSchedule;
                    currentSlotTimeUsed += (timeToSchedule + BUFFER_TIME);
                    scheduled = true;
                    
                    if (currentSlotTimeUsed >= currentSlot.getDurationHours() - 0.1) {
                        slotIndex++;
                        currentSlotTimeUsed = 0;
                    }
                } else {
                    slotIndex++;
                    currentSlotTimeUsed = 0;
                    
                    if (slotIndex >= availableSlots.size()) {
                        dayIndex++;
                        slotIndex = 0;
                    }
                }
                
                attempts++;
            }
            
            if (remainingTaskDuration > 0.1) {
                if (task.getPriority() == Priority.LOW) {
                    unscheduledTasks.add(task);
                    System.out.println("⚠ Note: Low priority task '" + task.getName() + 
                                     "' could not be fully scheduled due to insufficient time.");
                } else {
                    System.out.println("⚠ Warning: Could not fully schedule task: " + task.getName());
                    unscheduledTasks.add(task);
                }
            }
        }
        
        if (!unscheduledTasks.isEmpty()) {
            System.out.println("\n" + unscheduledTasks.size() + " task(s) could not be scheduled.");
            System.out.println("Consider extending your available time or adjusting priorities.");
        }
        
        return unscheduledTasks.isEmpty();
    }
    
    private String calculateTime(int startHour, int startMinute, double hoursToAdd) {
        int totalMinutes = (int)(hoursToAdd * 60);
        int hour = startHour + (startMinute + totalMinutes) / 60;
        int minute = (startMinute + totalMinutes) % 60;
        return String.format("%02d:%02d", hour, minute);
    }
    
    private boolean isWeekend(String day) {
        return day.equals("Saturday") || day.equals("Sunday");
    }
    
    public Map<String, List<ScheduledTask>> getSchedule() {
        return new LinkedHashMap<>(schedule);
    }
    
    public List<Task> getUnscheduledTasks() {
        return new ArrayList<>(unscheduledTasks);
    }
    
    public void removeTaskFromSchedule(String taskId) {
        for (List<ScheduledTask> dayTasks : schedule.values()) {
            dayTasks.removeIf(st -> st.getTask().getTaskId().equals(taskId));
        }
    }
    
    public void clearSchedule() {
        initializeSchedule();
        unscheduledTasks.clear();
    }
}